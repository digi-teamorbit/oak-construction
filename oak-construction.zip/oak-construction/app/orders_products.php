<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class orders_products extends Model
{
	protected $table = 'orders_products';
	public $primaryKey = 'orders_products_id';
   
} 
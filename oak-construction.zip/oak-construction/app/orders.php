<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class orders extends Model
{
	protected $table = 'orders';
	public $primaryKey = 'orders_id';
	
	
	
   
} 
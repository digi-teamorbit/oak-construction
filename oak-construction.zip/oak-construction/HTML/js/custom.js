
// slicknav-script

  $(function(){
    $('#menu').slicknav();
  });

// slicknav-script

// WOW-script

 new WOW().init();

// WOW-script

// owl-carousel script

  $('.OurService_slider').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
  });

  $('.OurProjects_slider').slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    arrows:true,
    autoplay: true,
    autoplaySpeed: 2000,
  });

// owl-carousel script



